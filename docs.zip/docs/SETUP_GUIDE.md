# SentinelAI – Complete Setup & Deployment Guide

## What This System Does

SentinelAI monitors all company machines for usage of 70+ AI tools including:
ChatGPT, Claude, Gemini, Perplexity, Copilot, Cursor, Midjourney, Stable Diffusion, and many more.

When detected, it:
- Sends an email alert with full details (machine, user, time, URL)
- Optionally sends Slack / Microsoft Teams notifications
- Logs everything to a central dashboard
- Works offline and queues events for later sync

---

## Folder Structure

```
ai-monitor/
├── agent/                      ← Runs on EACH employee machine
│   ├── monitor.py              ← Main monitoring agent
│   ├── config.json             ← Per-machine configuration
│   ├── requirements.txt        ← Python deps
│   ├── sentinelai_task.xml     ← Windows Task Scheduler autostart
│   ├── com.sentinelai.monitor.plist  ← macOS LaunchAgent autostart
│   └── sentinelai.service      ← Linux systemd autostart
│
├── server/                     ← Runs on ONE central server/laptop
│   ├── app.py                  ← Flask API + notification engine
│   ├── requirements.txt
│   └── server_config.json      ← Auto-created on first run
│
└── dashboard/                  ← Web dashboard (built once, served by Flask)
    ├── src/
    │   ├── main.jsx
    │   └── App.jsx
    ├── index.html
    ├── package.json
    └── vite.config.js
```

---

## STEP 1 — Set Up the Central Server

This runs on YOUR machine (or any always-on machine on the company network).

### 1.1 Install Python dependencies

```bash
cd ai-monitor/server
pip install -r requirements.txt
```

### 1.2 Build the Dashboard

```bash
cd ai-monitor/dashboard
npm install
npm run build
# This creates dashboard/dist/ folder
```

### 1.3 Start the server

```bash
cd ai-monitor/server
python app.py
```

You will see:
```
⚡ SentinelAI Server Starting
  Dashboard: http://localhost:5000
  API: http://localhost:5000/api/events
```

Open http://localhost:5000 in your browser — the dashboard should appear.

### 1.4 Find Your Server IP (so agents can connect)

```bash
# Windows
ipconfig
# Look for "IPv4 Address" e.g. 192.168.1.105

# Mac / Linux
ifconfig | grep "inet "
# or: ip addr show
```

Write down this IP — you'll need it for agent config.

### 1.5 Make Server Start Automatically (optional but recommended)

**Windows** — Create a batch file `start_server.bat`:
```batch
@echo off
cd C:\ai-monitor\server
python app.py
```
Add to Windows startup folder: Win+R → `shell:startup`

**Linux (systemd)**:
```bash
# Create service file at /etc/systemd/system/sentinelai-server.service
[Unit]
Description=SentinelAI Central Server
After=network.target

[Service]
WorkingDirectory=/opt/ai-monitor/server
ExecStart=/usr/bin/python3 app.py
Restart=always

[Install]
WantedBy=multi-user.target

# Then enable it:
sudo systemctl enable sentinelai-server
sudo systemctl start sentinelai-server
```

---

## STEP 2 — Configure Gmail for Email Alerts

Gmail requires an "App Password" — this is different from your regular password.

### 2.1 Enable 2-Step Verification on Gmail (required first)
1. Go to https://myaccount.google.com/security
2. Under "How you sign in to Google" → click "2-Step Verification"
3. Follow the steps to enable it

### 2.2 Generate an App Password
1. Go to https://myaccount.google.com/apppasswords
2. Select app: "Mail"
3. Select device: "Windows Computer" (or any)
4. Click "Generate"
5. Copy the 16-character password (e.g. `abcd efgh ijkl mnop`)

### 2.3 Configure SentinelAI

Open the dashboard at http://localhost:5000 → click Settings (bottom-left gear icon):

- **Enable Email Alerts** → ON
- **Gmail Address** → your Gmail (e.g. `sentinelai.company@gmail.com`)
- **App Password** → the 16-char password from step 2.2
- **Alert Recipients** → email(s) to receive alerts (can be multiple, comma-separated)
- Click **Save Settings**
- Click **Send Test Email** → you should receive a test alert

**Tip:** Create a dedicated Gmail just for this system, e.g. `companyname.monitor@gmail.com`

---

## STEP 3 — Deploy Agent on Employee Machines

For EACH machine you want to monitor:

### 3.1 Copy the agent folder

Copy the entire `agent/` folder to the machine. Suggested locations:
- **Windows:** `C:\SentinelAI\agent\`
- **Mac:** `/opt/sentinelai/agent/`
- **Linux:** `/opt/sentinelai/agent/`

### 3.2 Install Python (if not installed)

- Windows: Download from https://python.org — check "Add to PATH" during install
- Mac: `brew install python3` or download from python.org
- Linux: `sudo apt install python3 python3-pip`

### 3.3 Install agent dependencies

```bash
cd C:\SentinelAI\agent   # or wherever you copied it
pip install -r requirements.txt
```

### 3.4 Edit config.json

```json
{
  "server_url": "http://192.168.1.105:5000",   ← your server IP from Step 1.4
  "report_interval_seconds": 10,
  "machine_name": "JOHN-LAPTOP",               ← give this machine a clear name
  "employee_name": "John Smith",               ← employee's full name
  "department": "Marketing",                   ← their department
  "offline_queue_max": 500
}
```

### 3.5 Test the agent manually

```bash
python monitor.py
```

You should see output like:
```
[SentinelAI] Starting monitor on JOHN-LAPTOP
[SentinelAI] Reporting to http://192.168.1.105:5000
[SentinelAI] Tracking 70 AI tools
```

Now open ChatGPT in the browser — within 10 seconds you should see:
```
[DETECTED] ChatGPT via browser  |  https://chat.openai.com/...
```

And receive an email alert.

### 3.6 Set Agent to Auto-Start (so it survives reboots)

#### Windows (Task Scheduler — RECOMMENDED)

Option A — Command line (run as Administrator):
```cmd
schtasks /create /tn "SentinelAI Monitor" /tr "pythonw.exe C:\SentinelAI\agent\monitor.py" /sc onlogon /rl highest /f
```

Option B — Import XML:
```cmd
schtasks /create /xml "C:\SentinelAI\agent\sentinelai_task.xml" /tn "SentinelAI Monitor"
```
(Edit the XML first to fix the path to monitor.py)

**To verify it's scheduled:**
```cmd
schtasks /query /tn "SentinelAI Monitor"
```

#### macOS (LaunchAgent)

```bash
# Edit the plist to fix your Python path and agent path
nano /opt/sentinelai/agent/com.sentinelai.monitor.plist

# Install it
cp /opt/sentinelai/agent/com.sentinelai.monitor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.sentinelai.monitor.plist

# Verify it's running
launchctl list | grep sentinelai
```

#### Linux (systemd)

```bash
# Edit the service file with your username
nano /opt/sentinelai/agent/sentinelai.service

# Install it
sudo cp /opt/sentinelai/agent/sentinelai.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable sentinelai
sudo systemctl start sentinelai

# Check status
sudo systemctl status sentinelai
```

---

## STEP 4 — Configure Slack Notifications (Optional)

### 4.1 Create a Slack Incoming Webhook

1. Go to https://api.slack.com/apps → "Create New App" → "From scratch"
2. Name: "SentinelAI", pick your workspace → Create
3. In left sidebar → "Incoming Webhooks" → toggle ON
4. Click "Add New Webhook to Workspace"
5. Choose the channel (e.g. #it-alerts) → Allow
6. Copy the webhook URL (starts with `https://hooks.slack.com/services/...`)

### 4.2 Configure in Dashboard

Open Settings → Enable Slack Notifications → paste webhook URL → Save.

---

## STEP 5 — Configure Microsoft Teams (Optional)

1. In Teams, go to the channel where you want alerts
2. Click "..." → "Connectors" → "Incoming Webhook" → Configure
3. Give it a name "SentinelAI" → Create
4. Copy the webhook URL
5. In dashboard Settings → Enable Microsoft Teams → paste URL → Save

---

## STEP 6 — Other Ways to Receive Alerts

Besides Gmail, Slack, and Teams, SentinelAI supports:

### Generic Webhook
Point it at ANY URL to receive a JSON POST for each event.
Use cases:
- **Telegram Bot:** Use a Telegram bot webhook
- **Discord:** Use a Discord webhook URL
- **PagerDuty / Opsgenie:** Use their inbound webhook endpoints  
- **Your own backend:** Write a small receiver in any language
- **Zapier / Make.com:** Trigger any automation

**Telegram Bot Example:**
```python
# Create a bot via @BotFather on Telegram
# Get your chat_id by messaging @userinfobot
# Webhook URL format:
# https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<CHAT_ID>&text={tool}+detected

# Or use a Zapier webhook that forwards to Telegram
```

**Discord:**
1. Server Settings → Integrations → Webhooks → New Webhook
2. Copy URL → paste into SentinelAI's Generic Webhook field

### Local Log File
Every event is also written to `agent/sentinel_log.jsonl` on the agent machine.
You can read/parse this with any log viewer.

### API Access
The server exposes a full REST API:
- `GET /api/events` — all events (supports ?machine=, ?tool=, ?since=, ?limit= filters)
- `GET /api/stats` — dashboard statistics
- `GET /api/machines` — machine list
- `POST /api/events` — receive new event

Build your own integration with these endpoints.

---

## Deploying at Scale (Multiple Machines Quickly)

### Option A — USB Drive / Network Share Deployment

1. Prepare one configured `agent/` folder with the right `server_url`
2. Copy it to each machine (USB, network share, or email)
3. On each machine: run the Task Scheduler command above, then reboot

### Option B — Silent Install Script (Windows)

Create `deploy.bat` and run as admin on each machine:
```batch
@echo off
echo Installing SentinelAI...

:: Create directory
mkdir C:\SentinelAI\agent

:: Copy files (from USB or network share)
xcopy /E /I "\\server\share\sentinelai\agent" "C:\SentinelAI\agent"

:: Install Python deps silently
pip install psutil requests --quiet

:: Create scheduled task
schtasks /create /tn "SentinelAI Monitor" ^
  /tr "pythonw.exe C:\SentinelAI\agent\monitor.py" ^
  /sc onlogon /rl highest /f /ru SYSTEM

echo Done! SentinelAI is now monitoring this machine.
pause
```

---

## Firewall / Network Notes

The agent makes outbound HTTP connections to your server on port 5000.

- If machines are behind a firewall, open port 5000 on the server machine
- If using Windows Firewall: `netsh advfirewall firewall add rule name="SentinelAI" dir=in action=allow protocol=TCP localport=5000`
- The agent works offline too — it queues events locally and syncs when the server is reachable again

---

## Alert Tuning Tips

In `server_config.json` (or via the Settings panel):

| Setting | Recommended |
|---------|-------------|
| `alert_cooldown_minutes` | 60 (one alert per tool per machine per hour) |
| `business_hours_only` | true (only alert 9–18 on weekdays) |
| `blocked_tools` | Add tools that are 100% prohibited (always alerts) |
| `report_interval_seconds` | 10 (agent scan frequency) |

---

## Troubleshooting

**Agent shows "Connection refused":**
- Make sure the server is running (`python app.py`)  
- Check the IP in config.json is correct
- Check firewall isn't blocking port 5000

**No browser history being read:**
- Make sure Chrome/Firefox are installed and have been used
- On Windows, run the agent as the logged-in user (not SYSTEM)
- Chrome must NOT be running in Incognito for history to be captured

**Email not sending:**
- Verify 2-Step Verification is ON on Gmail
- Use App Password, NOT your regular Gmail password  
- Check `smtp_user` and `smtp_password` in settings
- Click "Send Test Email" to diagnose

**Agent not auto-starting:**
- Windows: Open Task Scheduler → look for "SentinelAI Monitor"
- Mac: `launchctl list | grep sentinel`
- Linux: `systemctl status sentinelai`

---

## Privacy & Legal Note

Before deploying on company machines, consult your company's IT policy and HR. 
In many jurisdictions, employee monitoring requires written disclosure.
Add a note in the employee handbook or IT policy about AI tool monitoring.
