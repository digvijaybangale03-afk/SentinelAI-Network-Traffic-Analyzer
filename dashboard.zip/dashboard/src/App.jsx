import { useState, useEffect, useCallback } from "react";
import { Shield, Activity, Monitor, Bell, Settings, RefreshCw,
         AlertTriangle, TrendingUp, Users, Zap, Search, Download,
         CheckCircle, XCircle, Clock, BarChart2, Globe, Cpu } from "lucide-react";
import "./styles.css";

const API = window.location.hostname === "localhost" || window.location.port
  ? `http://${window.location.hostname}:5000/api`
  : "/api";

const FETCH_OPTIONS = { cache: "no-store" };

const CATEGORY_COLORS = {
  "Chat AI":        { bg: "#FCE7F3", text: "#9D174D", dot: "#EC4899" },
  "Coding AI":      { bg: "#DBEAFE", text: "#1E40AF", dot: "#3B82F6" },
  "Image/Video AI": { bg: "#FEF3C7", text: "#92400E", dot: "#F59E0B" },
  "Audio AI":       { bg: "#D1FAE5", text: "#065F46", dot: "#10B981" },
  "Writing AI":     { bg: "#EDE9FE", text: "#5B21B6", dot: "#8B5CF6" },
  "Research AI":    { bg: "#FEE2E2", text: "#991B1B", dot: "#EF4444" },
  "Business AI":    { bg: "#F0FDF4", text: "#166534", dot: "#22C55E" },
  "API/Dev":        { bg: "#F0F9FF", text: "#0C4A6E", dot: "#0EA5E9" },
  "Search AI":      { bg: "#FFF7ED", text: "#92400E", dot: "#F97316" },
  "Other AI":       { bg: "#F3F4F6", text: "#374151", dot: "#9CA3AF" },
};

function CategoryBadge({ category }) {
  const c = CATEGORY_COLORS[category] || CATEGORY_COLORS["Other AI"];
  return (
    <span className="badge" style={{ background: c.bg, color: c.text, fontSize: 11, fontWeight: 600 }}>
      {category}
    </span>
  );
}

function StatCard({ icon: Icon, label, value, sub, color = "#7C3AED" }) {
  return (
    <div className="dashboard-card">
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <div className="stat-icon" style={{ background: color + "22" }}>
          <Icon size={22} color={color} />
        </div>
        <div>
          <div className="stat-value">{value}</div>
          <div className="stat-title">{label}</div>
          {sub && <div style={{ fontSize: 12, color: "#64748b", marginTop: 6 }}>{sub}</div>}
        </div>
      </div>
    </div>
  );
}

function EventRow({ event }) {
  const ts = new Date(event.timestamp).toLocaleString();
  return (
    <tr className="table-row">
      <td>{ts}</td>
      <td style={{ fontWeight: 600, color: "#111" }}>{event.tool}</td>
      <td><CategoryBadge category={event.category} /></td>
      <td style={{ color: "#64748b", fontFamily: "monospace", fontSize: 12 }}>{event.machine}</td>
      <td style={{ color: "#64748b" }}>{event.employee || event.os_user}</td>
      <td style={{ color: "#94a3b8", fontSize: 12, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {event.url || "—"}
      </td>
      <td>
        <span className="badge" style={{ background: "#eff6ff", color: "#1d4ed8" }}>{event.match_type}</span>
      </td>
    </tr>
  );
}

function MiniBar({ label, value, max, color }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
        <span style={{ color: "#374151" }}>{label}</span>
        <span style={{ color: "#6B7280", fontWeight: 600 }}>{value}</span>
      </div>
      <div style={{ height: 6, background: "#F3F4F6", borderRadius: 3 }}>
        <div style={{ height: 6, background: color, borderRadius: 3, width: pct + "%" }} />
      </div>
    </div>
  );
}

function ActivityChart({ data }) {
  if (!data || data.length === 0) return (
    <div style={{ textAlign: "center", color: "#9CA3AF", padding: 32, fontSize: 13 }}>No data yet</div>
  );
  const max = Math.max(...data.map(d => d.count));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 80, padding: "0 4px" }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
          <div style={{
            width: "100%", background: "#7C3AED",
            height: max > 0 ? Math.max(4, Math.round((d.count / max) * 70)) : 4,
            borderRadius: "2px 2px 0 0", opacity: 0.8,
          }} title={`${d.day}: ${d.count}`} />
          <div style={{ fontSize: 9, color: "#9CA3AF", whiteSpace: "nowrap" }}>
            {d.day?.slice(5)}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Settings Panel ────────────────────────────────────────────────────────────

function SettingsPanel({ onClose }) {
  const [cfg, setCfg] = useState(null);
  const [saving, setSaving] = useState(false);
  const [testStatus, setTestStatus] = useState(null);

  useEffect(() => {
    fetch(`${API}/config`, FETCH_OPTIONS).then(r => r.json()).then(setCfg);
  }, []);

  async function save() {
    setSaving(true);
    await fetch(`${API}/config`, { method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify(cfg) });
    setSaving(false);
  }

  async function testEmail() {
    setTestStatus("sending");
    const r = await fetch(`${API}/test-email`, { method: "POST" });
    const d = await r.json();
    setTestStatus(d.ok ? "ok" : "fail");
    setTimeout(() => setTestStatus(null), 4000);
  }

  if (!cfg) return <div style={{ padding: 40, textAlign: "center", color: "#9CA3AF" }}>Loading…</div>;

  const field = (label, key, type = "text", placeholder = "") => (
    <div className="form-field">
      <label>{label}</label>
      <input type={type} value={cfg[key] || ""} placeholder={placeholder}
        onChange={e => setCfg({ ...cfg, [key]: e.target.value })} />
    </div>
  );

  const toggle = (label, key, sub = "") => (
    <div className="setting-card">
      <div>
        <div style={{ fontSize: 14, color: "#111", fontWeight: 500 }}>{label}</div>
        {sub && <div style={{ fontSize: 12, color: "#64748b" }}>{sub}</div>}
      </div>
      <div className="toggle-switch" onClick={() => setCfg({ ...cfg, [key]: !cfg[key] })}
        style={{ background: cfg[key] ? "#7C3AED" : "#E5E7EB" }}>
        <div className="thumb" style={{ left: cfg[key] ? 20 : 4 }} />
      </div>
    </div>
  );

  return (
    <div className="settings-overlay">
      <div className="settings-modal animated-panel">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Settings</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer",
            color: "#64748b", fontSize: 20 }}>✕</button>
        </div>

        <h3 style={{ fontSize: 14, fontWeight: 700, color: "#7C3AED", marginBottom: 16 }}>Email Alerts (Gmail)</h3>
        {toggle("Enable Email Alerts", "email_enabled")}
        {field("SMTP Host", "smtp_host", "text", "smtp.gmail.com")}
        {field("Gmail Address", "smtp_user", "email", "yourname@gmail.com")}
        {field("App Password", "smtp_password", "password", "xxxx xxxx xxxx xxxx")}
        <div style={{ marginBottom: 16 }}>
          <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#6B7280",
            textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>Alert Recipients (comma-separated)</label>
          <input value={(cfg.alert_recipients || []).join(", ")}
            onChange={e => setCfg({ ...cfg, alert_recipients: e.target.value.split(",").map(s => s.trim()) })}
            style={{ width: "100%", padding: "8px 12px", borderRadius: 8, border: "1px solid #E5E7EB",
              fontSize: 13, color: "#111", outline: "none", boxSizing: "border-box" }} />
        </div>
        <button onClick={testEmail} disabled={testStatus === "sending"}
          style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid #7C3AED",
            background: "none", color: "#7C3AED", fontSize: 13, cursor: "pointer", marginBottom: 24 }}>
          {testStatus === "sending" ? "Sending…" : testStatus === "ok" ? "✓ Sent!" : testStatus === "fail" ? "✗ Failed" : "Send Test Email"}
        </button>

        <h3 style={{ fontSize: 14, fontWeight: 700, color: "#7C3AED", marginBottom: 16 }}>Other Channels</h3>
        {toggle("Enable Slack Notifications", "slack_enabled")}
        {cfg.slack_enabled && field("Slack Webhook URL", "slack_webhook_url", "text", "https://hooks.slack.com/…")}
        {toggle("Enable Microsoft Teams", "teams_enabled")}
        {cfg.teams_enabled && field("Teams Webhook URL", "teams_webhook_url", "text", "https://…")}
        {toggle("Enable Generic Webhook", "generic_webhook_enabled", "POST JSON to any endpoint")}
        {cfg.generic_webhook_enabled && field("Webhook URL", "generic_webhook_url")}

        <h3 style={{ fontSize: 14, fontWeight: 700, color: "#7C3AED", marginBottom: 16, marginTop: 24 }}>Alert Rules</h3>
        {field("Alert Cooldown (minutes)", "alert_cooldown_minutes", "number")}
        {toggle("Business Hours Only", "business_hours_only", "Only alert Mon–Fri 9–18")}

        <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
          <button onClick={save} disabled={saving} className="btn btn-primary" style={{ flex: 1, justifyContent: "center" }}>
            {saving ? "Saving…" : "Save Settings"}
          </button>
          <button onClick={onClose} className="secondary-cta">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [stats, setStats] = useState(null);
  const [currentEvents, setCurrentEvents] = useState([]);
  const [historyEvents, setHistoryEvents] = useState([]);
  const [machines, setMachines] = useState([]);
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("");
  const [filterMachine, setFilterMachine] = useState("");
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [historyStartDate, setHistoryStartDate] = useState("");
  const [historyEndDate, setHistoryEndDate] = useState("");
  const [tab, setTab] = useState("events"); // events | machines | analytics

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [s, current, history, m] = await Promise.all([
        fetch(`${API}/stats`, FETCH_OPTIONS).then(r => r.json()),
        fetch(`${API}/events?limit=300&session=current`, FETCH_OPTIONS).then(r => r.json()),
        fetch(`${API}/events?limit=300&session=history${historyStartDate ? `&since=${historyStartDate}T00:00:00Z` : ""}${historyEndDate ? `&until=${historyEndDate}T23:59:59Z` : ""}` , FETCH_OPTIONS).then(r => r.json()),
        fetch(`${API}/machines`, FETCH_OPTIONS).then(r => r.json()),
      ]);
      setStats(s);
      setCurrentEvents(current);
      setHistoryEvents(history);
      setMachines(m);
      setLastRefresh(new Date().toLocaleTimeString());
    } catch(err) {
      console.error("API error:", err);
    }
    setLoading(false);
  }, [historyStartDate, historyEndDate]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const t = setInterval(refresh, 30000);
    return () => clearInterval(t);
  }, [refresh]);

  const filtered = currentEvents.filter(e => {
    if (filterCat && e.category !== filterCat) return false;
    if (filterMachine && e.machine !== filterMachine) return false;
    if (search) {
      const q = search.toLowerCase();
      return e.tool.toLowerCase().includes(q) || e.machine.toLowerCase().includes(q)
        || (e.employee || "").toLowerCase().includes(q) || (e.url || "").toLowerCase().includes(q);
    }
    return true;
  });

  const filteredHistory = historyEvents.filter(e => {
    if (filterCat && e.category !== filterCat) return false;
    if (filterMachine && e.machine !== filterMachine) return false;
    if (search) {
      const q = search.toLowerCase();
      return e.tool.toLowerCase().includes(q) || e.machine.toLowerCase().includes(q)
        || (e.employee || "").toLowerCase().includes(q) || (e.url || "").toLowerCase().includes(q);
    }
    return true;
  });

  const categories = [...new Set([...currentEvents, ...historyEvents].map(e => e.category))].filter(Boolean);
  const machineNames = [...new Set([...currentEvents, ...historyEvents].map(e => e.machine))].filter(Boolean);

  const groupedHistory = filteredHistory.reduce((acc, e) => {
    const day = e.timestamp?.slice(0, 10) || "Unknown date";
    if (!acc[day]) acc[day] = [];
    acc[day].push(e);
    return acc;
  }, {});

  const sortedHistoryDays = Object.keys(groupedHistory).sort((a, b) => b.localeCompare(a));

  function exportExcel() {
    const cols = ["timestamp","tool","category","machine","employee","department","url","match_type","matched_pattern","os_user","platform"];
    const escape = (value) => String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");

    const rowXml = filtered.map(e => `      <Row>${cols.map(c => `
        <Cell><Data ss:Type="String">${escape(e[c])}</Data></Cell>`).join("")}
      </Row>`).join("\n");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
          xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:x="urn:schemas-microsoft-com:office:excel"
          xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Worksheet ss:Name="Detections">
    <Table>
      <Row>${cols.map(c => `<Cell><Data ss:Type="String">${escape(c)}</Data></Cell>`).join("")}</Row>
${rowXml}
    </Table>
  </Worksheet>
</Workbook>`;

    const blob = new Blob([xml], { type: "application/vnd.ms-excel" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `sentinelai_export_${new Date().toISOString().slice(0,10)}.xls`;
    a.click();
  }

  return (
    <div className="app-shell">
      <div className="background-shape shape-1" />
      <div className="background-shape shape-2" />
      <div className="background-shape shape-3" />
      {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} />}

      {/* Sidebar */}
      <div className="sidebar">
        <div className="brand">
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
            <div style={{ width: 38, height: 38, borderRadius: 12, background: "linear-gradient(135deg,#7C3AED,#4F46E5)",
              display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Shield size={20} color="#fff" />
            </div>
            <div>
              <div className="brand-title" style={{ fontSize: 17, fontWeight: 800 }}>SentinelAI</div>
              <div style={{ color: "#a5b4fc", fontSize: 12 }}>AI Activity Monitor</div>
            </div>
          </div>
        </div>
        <nav>
          {[
            { id: "events", icon: Activity, label: "Live Events" },
            { id: "machines", icon: Monitor, label: "Machines" },
            { id: "analytics", icon: BarChart2, label: "Analytics" },
          ].map(({ id, icon: Icon, label }) => (
            <button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id)}>
              <Icon size={16} /> {label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <button onClick={() => setShowSettings(true)}>
            <Settings size={16} /> Settings
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="main">
        {/* Header */}
        <div className="section-header">
          <div>
            <h1>{tab === "events" ? "Live Events" : tab === "machines" ? "Monitored Machines" : "Analytics"}</h1>
            <div className="meta">
              {lastRefresh ? `Last updated ${lastRefresh}` : "Loading…"}
              {stats?.session_start && (
                <span> · Current session since {new Date(stats.session_start).toLocaleString()}</span>
              )}
            </div>
          </div>
          <div className="toolbar">
            <button className="btn btn-secondary" onClick={exportExcel}>
              <Download size={14} /> Export Excel
            </button>
            <button className="btn btn-primary" onClick={refresh} disabled={loading}>
              <RefreshCw size={14} className={loading ? "spin" : ""} /> Refresh
            </button>
          </div>
        </div>

        {/* Stat Cards */}
        {stats && (
          <div className="dashboard-grid">
            <StatCard icon={Zap} label="Session Detections" value={stats.current_session_events} sub="since restart" color="#7C3AED" />
            <StatCard icon={Clock} label="Today" value={stats.today_events} sub="past 24h" color="#3B82F6" />
            <StatCard icon={Monitor} label="Machines" value={stats.unique_machines} color="#10B981" />
            <StatCard icon={Globe} label="Tools Detected" value={stats.unique_tools} color="#F59E0B" />
          </div>
        )}

        {/* Events Tab */}
        {tab === "events" && (
          <>
            {/* Filters */}
            <div className="filter-row">
              <div style={{ position: "relative" }}>
                <Search size={14} style={{ position: "absolute", left: 14, top: "50%",
                  transform: "translateY(-50%)", color: "#94a3b8" }} />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search by tool, machine, user, URL…"
                  style={{ width: "100%", padding: "12px 14px 12px 38px" }} />
              </div>
              <select value={filterCat} onChange={e => setFilterCat(e.target.value)}>
                <option value="">All Categories</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={filterMachine} onChange={e => setFilterMachine(e.target.value)}>
                <option value="">All Machines</option>
                {machineNames.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>

            {/* Events Table */}
            <div className="page-panel">
              <header>
                <span>{filtered.length} events</span>
                <div style={{ fontSize: 12, color: "#64748b" }}>Auto-refreshes every 30s</div>
              </header>
              <div style={{ overflowX: "auto" }}>
                <table>
                  <thead>
                    <tr>
                      {["Timestamp","Tool","Category","Machine","User","URL","Detection"].map(h => (
                        <th key={h}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.length === 0 ? (
                      <tr><td colSpan={7} style={{ padding: 40, textAlign: "center", color: "#9CA3AF", fontSize: 13 }}>
                        No events yet. Deploy agents to start monitoring.
                      </td></tr>
                    ) : filtered.map(e => <EventRow key={e.id + e.timestamp} event={e} />)}
                  </tbody>
                </table>
              </div>
            </div>

            {historyEvents.length > 0 && (
              <div className="page-panel" style={{ marginTop: 20 }}>
                <header>
                  <span>Previous session history: {filteredHistory.length} events</span>
                  <button onClick={() => setShowHistory(!showHistory)} className="panel-action">
                    {showHistory ? "Hide history" : "Show history"}
                  </button>
                </header>
                {showHistory && (
                  <div style={{ padding: 16, borderTop: "1px solid #F3F4F6" }}>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 14 }}>
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 180 }}>
                        <label style={{ fontSize: 12, fontWeight: 600, color: "#6B7280" }}>History From</label>
                        <input type="date" value={historyStartDate} onChange={e => setHistoryStartDate(e.target.value)}
                          style={{ padding: "9px 12px", borderRadius: 10, border: "1px solid #E5E7EB",
                            fontSize: 13, color: "#111", background: "#fff" }} />
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 180 }}>
                        <label style={{ fontSize: 12, fontWeight: 600, color: "#6B7280" }}>History Until</label>
                        <input type="date" value={historyEndDate} onChange={e => setHistoryEndDate(e.target.value)}
                          style={{ padding: "9px 12px", borderRadius: 10, border: "1px solid #E5E7EB",
                            fontSize: 13, color: "#111", background: "#fff" }} />
                      </div>
                      {(historyStartDate || historyEndDate) && (
                        <button onClick={() => { setHistoryStartDate(""); setHistoryEndDate(""); }}
                          className="panel-action" style={{ alignSelf: "end" }}>Clear range</button>
                      )}
                    </div>
                    <div style={{ overflowX: "auto" }}>
                    <table>
                      <thead>
                        <tr>
                          {["Timestamp","Tool","Category","Machine","User","URL","Detection"].map(h => (
                            <th key={h}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {filteredHistory.length === 0 ? (
                          <tr><td colSpan={7} style={{ padding: 40, textAlign: "center", color: "#9CA3AF", fontSize: 13 }}>
                            No history events match the current filters.
                          </td></tr>
                        ) : (
                          sortedHistoryDays.map(day => (
                            <>
                              <tr>
                                <td colSpan={7} style={{ padding: "12px 12px", background: "#F8F7FF",
                                  color: "#5B5B86", fontSize: 13, fontWeight: 700 }}>
                                  {new Date(day).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' })} — {groupedHistory[day].length} events
                                </td>
                              </tr>
                              {groupedHistory[day].map(e => <EventRow key={e.id + e.timestamp} event={e} />)}
                            </>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
                )}
              </div>
            )}
          </>
        )}

        {/* Machines Tab */}
        {tab === "machines" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px,1fr))", gap: 16 }}>
            {machines.length === 0 ? (
              <div style={{ background: "#fff", borderRadius: 16, padding: 40, textAlign: "center",
                color: "#9CA3AF", gridColumn: "1/-1" }}>
                No machines reporting yet. Deploy the agent on employee machines.
              </div>
            ) : machines.map(m => (
              <div key={m.machine} style={{ background: "#fff", borderRadius: 16, padding: 20,
                border: "1px solid #F3F4F6", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: "#EDE9FE",
                    display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Monitor size={18} color="#7C3AED" />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: "#111", fontSize: 15 }}>{m.machine}</div>
                    <div style={{ fontSize: 11, color: "#9CA3AF" }}>
                      Last seen: {new Date(m.last_seen).toLocaleString()}
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                  <div style={{ background: "#F3F4F6", borderRadius: 8, padding: "6px 12px",
                    fontSize: 12, color: "#374151" }}>
                    <strong>{m.total_events}</strong> detections
                  </div>
                  <div style={{ background: "#F3F4F6", borderRadius: 8, padding: "6px 12px",
                    fontSize: 12, color: "#374151" }}>
                    <strong>{m.tools_used?.length || 0}</strong> tools
                  </div>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                  {(m.tools_used || []).slice(0, 6).map(t => (
                    <span key={t} style={{ fontSize: 11, background: "#F3F4F6", color: "#6B7280",
                      padding: "2px 6px", borderRadius: 4 }}>{t}</span>
                  ))}
                  {m.tools_used?.length > 6 && (
                    <span style={{ fontSize: 11, color: "#9CA3AF" }}>+{m.tools_used.length - 6} more</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Analytics Tab */}
        {tab === "analytics" && stats && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <div style={{ background: "#fff", borderRadius: 16, padding: 24,
              border: "1px solid #F3F4F6", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700, color: "#111" }}>Top AI Tools</h3>
              {stats.top_tools.map((t, i) => (
                <MiniBar key={t.tool} label={t.tool} value={t.count}
                  max={stats.top_tools[0]?.count || 1} color="#7C3AED" />
              ))}
            </div>
            <div style={{ background: "#fff", borderRadius: 16, padding: 24,
              border: "1px solid #F3F4F6", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700, color: "#111" }}>Top Machines</h3>
              {stats.top_machines.map(m => (
                <MiniBar key={m.machine} label={m.machine} value={m.count}
                  max={stats.top_machines[0]?.count || 1} color="#3B82F6" />
              ))}
            </div>
            <div style={{ background: "#fff", borderRadius: 16, padding: 24,
              border: "1px solid #F3F4F6", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700, color: "#111" }}>By Category</h3>
              {stats.by_category.map(c => (
                <MiniBar key={c.category} label={c.category} value={c.count}
                  max={stats.by_category[0]?.count || 1}
                  color={CATEGORY_COLORS[c.category]?.dot || "#9CA3AF"} />
              ))}
            </div>
            <div style={{ background: "#fff", borderRadius: 16, padding: 24,
              border: "1px solid #F3F4F6", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700, color: "#111" }}>7-Day Activity</h3>
              <ActivityChart data={stats.daily_activity} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
