"""
SentinelAI - Central Server
Receives events from agents, stores them, sends alerts, and serves the dashboard.
"""

import os
import json
import sqlite3
import smtplib
import threading
import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# ─── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "sentinel.db"
CONFIG_PATH = BASE_DIR / "server_config.json"
SESSION_STATE_PATH = BASE_DIR / "session_state.json"
DASHBOARD_DIR = BASE_DIR.parent / "dashboard" / "dist"

CURRENT_SESSION_START = None

# ─── Default Server Config ─────────────────────────────────────────────────────
DEFAULT_SERVER_CONFIG = {
    "host": "0.0.0.0",
    "port": 5000,

    # ── Email settings ──────────────────────────────────────────────────────
    "email_enabled": False,
    "smtp_host": "smtp.gmail.com",
    "smtp_port": 587,
    "smtp_user": "your_email@gmail.com",
    "smtp_password": "your_app_password_here",
    "alert_recipients": ["admin@company.com"],
    "email_from_name": "SentinelAI Monitor",

    # ── Slack / Teams / Webhook ─────────────────────────────────────────────
    "slack_enabled": False,
    "slack_webhook_url": "",
    "teams_enabled": False,
    "teams_webhook_url": "",
    "generic_webhook_enabled": False,
    "generic_webhook_url": "",

    # ── Alert Rules ─────────────────────────────────────────────────────────
    "alert_on_first_detection": True,
    "alert_cooldown_minutes": 60,   # per machine per tool
    "blocked_tools": [],            # tools that trigger immediate alert regardless
    "watched_categories": [],       # e.g. ["Coding AI"] - extra alerts
    "business_hours_only": False,   # only alert 9-18 on weekdays
    "business_hours_start": 9,
    "business_hours_end": 18,

    # ── Misc ─────────────────────────────────────────────────────────────────
    "secret_key": "change_this_secret_key_12345",
    "retention_days": 90,
}

# ─── App Setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=str(DASHBOARD_DIR))
CORS(app)

@app.after_request
def add_no_cache_headers(response):
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

_alert_cooldowns: dict = {}   # (machine, tool) -> last alert time
_config_cache: dict = {}
_config_mtime = 0


def load_server_config() -> dict:
    global _config_cache, _config_mtime
    try:
        mtime = CONFIG_PATH.stat().st_mtime
        if mtime != _config_mtime:
            with open(CONFIG_PATH) as f:
                _config_cache = {**DEFAULT_SERVER_CONFIG, **json.load(f)}
            _config_mtime = mtime
    except FileNotFoundError:
        _config_cache = DEFAULT_SERVER_CONFIG.copy()
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_SERVER_CONFIG, f, indent=2)

    # Allow sensitive overrides from environment variables.
    if os.getenv("SMTP_USER"):
        _config_cache["smtp_user"] = os.getenv("SMTP_USER")
    if os.getenv("SMTP_PASSWORD"):
        _config_cache["smtp_password"] = os.getenv("SMTP_PASSWORD")
    if os.getenv("ALERT_RECIPIENTS"):
        _config_cache["alert_recipients"] = [s.strip() for s in os.getenv("ALERT_RECIPIENTS").split(",") if s.strip()]
    return _config_cache


# ─── Database ──────────────────────────────────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            tool TEXT NOT NULL,
            category TEXT,
            source TEXT,
            url TEXT,
            match_type TEXT,
            matched_pattern TEXT,
            machine TEXT,
            employee TEXT,
            department TEXT,
            hostname TEXT,
            os_user TEXT,
            platform TEXT,
            notified INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_timestamp ON events(timestamp DESC)
    """)
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_machine ON events(machine)
    """)
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_tool ON events(tool)
    """)
    conn.commit()
    conn.close()


def insert_event(event: dict):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT OR REPLACE INTO events
        (id, timestamp, tool, category, source, url, match_type,
         matched_pattern, machine, employee, department, hostname,
         os_user, platform)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        event.get("id", ""),
        event.get("timestamp", ""),
        event.get("tool", ""),
        event.get("category", ""),
        event.get("source", ""),
        event.get("url", ""),
        event.get("match_type", ""),
        event.get("matched_pattern", ""),
        event.get("machine", ""),
        event.get("employee", ""),
        event.get("department", ""),
        event.get("hostname", ""),
        event.get("os_user", ""),
        event.get("platform", ""),
    ))
    conn.commit()
    conn.close()


def query_events(filters: dict = {}, limit: int = 200) -> list:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    where = []
    params = []
    if filters.get("machine"):
        where.append("machine = ?"); params.append(filters["machine"])
    if filters.get("tool"):
        where.append("tool LIKE ?"); params.append(f"%{filters['tool']}%")
    if filters.get("category"):
        where.append("category = ?"); params.append(filters["category"])
    if filters.get("since"):
        where.append("timestamp >= ?"); params.append(filters["since"])
    if filters.get("until"):
        where.append("timestamp <= ?"); params.append(filters["until"])
    if filters.get("session") in ("current", "history"):
        session_start = CURRENT_SESSION_START or datetime.datetime.utcnow().isoformat() + "Z"
        if filters.get("session") == "current":
            where.append("timestamp >= ?"); params.append(session_start)
        else:
            where.append("timestamp < ?"); params.append(session_start)
    sql = "SELECT * FROM events"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    c.execute(sql, params)
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_stats() -> dict:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM events")
    total = c.fetchone()[0]
    c.execute("SELECT COUNT(DISTINCT machine) FROM events")
    machines = c.fetchone()[0]
    c.execute("SELECT COUNT(DISTINCT tool) FROM events")
    tools = c.fetchone()[0]
    session_start = CURRENT_SESSION_START or datetime.datetime.utcnow().isoformat() + "Z"
    c.execute("SELECT COUNT(*) FROM events WHERE timestamp >= ?", (session_start,))
    current_session_events = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM events WHERE timestamp < ?", (session_start,))
    previous_session_events = c.fetchone()[0]
    c.execute("SELECT tool, COUNT(*) as cnt FROM events GROUP BY tool ORDER BY cnt DESC LIMIT 10")
    top_tools = [{"tool": r[0], "count": r[1]} for r in c.fetchall()]
    c.execute("SELECT machine, COUNT(*) as cnt FROM events GROUP BY machine ORDER BY cnt DESC LIMIT 10")
    top_machines = [{"machine": r[0], "count": r[1]} for r in c.fetchall()]
    c.execute("SELECT category, COUNT(*) as cnt FROM events GROUP BY category ORDER BY cnt DESC")
    by_category = [{"category": r[0], "count": r[1]} for r in c.fetchall()]
    # Last 7 days activity
    c.execute("""
        SELECT DATE(timestamp) as day, COUNT(*) as cnt
        FROM events
        WHERE timestamp >= datetime('now', '-7 days')
        GROUP BY day ORDER BY day
    """)
    daily = [{"day": r[0], "count": r[1]} for r in c.fetchall()]
    # Today
    c.execute("SELECT COUNT(*) FROM events WHERE DATE(timestamp) = DATE('now')")
    today = c.fetchone()[0]
    # This week
    c.execute("SELECT COUNT(*) FROM events WHERE timestamp >= datetime('now', '-7 days')")
    this_week = c.fetchone()[0]
    conn.close()
    return {
        "total_events": total,
        "unique_machines": machines,
        "unique_tools": tools,
        "today_events": today,
        "week_events": this_week,
        "current_session_events": current_session_events,
        "previous_session_events": previous_session_events,
        "session_start": session_start,
        "top_tools": top_tools,
        "top_machines": top_machines,
        "by_category": by_category,
        "daily_activity": daily,
    }


# ─── Notification Engine ───────────────────────────────────────────────────────

def _cooldown_key(event: dict) -> str:
    return f"{event.get('machine','')}::{event.get('tool','')}"


def _is_in_business_hours(cfg: dict) -> bool:
    now = datetime.datetime.now()
    if now.weekday() >= 5:  # Sat/Sun
        return False
    return cfg["business_hours_start"] <= now.hour < cfg["business_hours_end"]


def should_alert(event: dict, cfg: dict) -> bool:
    if cfg.get("business_hours_only") and not _is_in_business_hours(cfg):
        print(f"[ALERT] Skipped email due to business hours: {event.get('tool')} on {event.get('machine')}")
        return False

    if not cfg.get("alert_on_first_detection", True):
        # When disabled, always alert regardless of cooldown
        return True

    key = _cooldown_key(event)
    now = datetime.datetime.utcnow()
    last = _alert_cooldowns.get(key)
    cooldown = datetime.timedelta(minutes=cfg.get("alert_cooldown_minutes", 60))
    if last and (now - last) < cooldown:
        if event.get("tool") not in cfg.get("blocked_tools", []):
            print(f"[ALERT] Skipped email because alert cooldown is active for {key}")
            return False
    _alert_cooldowns[key] = now
    return True


def _format_event_timestamp(timestamp: str) -> str:
    if not timestamp:
        return datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    try:
        if timestamp.endswith("Z"):
            dt = datetime.datetime.fromisoformat(timestamp[:-1]).replace(tzinfo=datetime.timezone.utc)
        else:
            dt = datetime.datetime.fromisoformat(timestamp)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
        dt = dt.astimezone()
        return dt.strftime("%Y-%m-%d %H:%M:%S %Z")
    except ValueError:
        return timestamp.replace("T", " ")[:19]


def send_email_alert(event: dict, cfg: dict) -> bool:
    ts = _format_event_timestamp(event.get("timestamp", ""))
    try:
        if not cfg.get("alert_recipients"):
            print(f"[MAIL ERROR] No alert recipients configured for email notifications")
            return False

        if not cfg.get("smtp_user") or not cfg.get("smtp_password") or cfg.get("smtp_password") in ["", "***"]:
            print(f"[MAIL ERROR] SMTP credentials are missing or invalid in server_config.json")
            return False

        subject = f"[SentinelAI] {event['tool']} detected on {event['machine']}"

        url_line = (
            f"<tr><td>URL</td><td><a href='{event['url']}'>{event['url'][:100]}</a></td></tr>"
            if event.get("url")
            else ""
        )

        html = f"""
<!DOCTYPE html>
<html>
<head>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background:#f4f6f9;
      margin:0;
      padding:20px;
    }}

    .card {{
      background:#fff;
      border-radius:12px;
      padding:32px;
      max-width:560px;
      margin:0 auto;
      box-shadow:0 2px 12px rgba(0,0,0,0.08);
    }}

    .badge {{
      display:inline-block;
      background:#FEF3C7;
      color:#92400E;
      padding:4px 10px;
      border-radius:20px;
      font-size:13px;
      font-weight:600;
    }}

    .badge.coding {{
      background:#DBEAFE;
      color:#1E40AF;
    }}

    .badge.chat {{
      background:#FCE7F3;
      color:#9D174D;
    }}

    h2 {{
      margin:0 0 4px;
      font-size:22px;
      color:#111;
    }}

    .sub {{
      color:#6B7280;
      font-size:14px;
      margin-bottom:24px;
    }}

    table {{
      width:100%;
      border-collapse:collapse;
    }}

    td {{
      padding:10px 12px;
      border-bottom:1px solid #F3F4F6;
      font-size:14px;
      color:#374151;
    }}

    td:first-child {{
      font-weight:600;
      color:#6B7280;
      width:130px;
    }}

    .footer {{
      margin-top:24px;
      font-size:12px;
      color:#9CA3AF;
      text-align:center;
    }}

    .alert-bar {{
      background:#FEF2F2;
      border:1px solid #FECACA;
      border-radius:8px;
      padding:12px 16px;
      margin-bottom:20px;
      color:#991B1B;
      font-size:13px;
    }}
  </style>
</head>

<body>

<div class="card">

  <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">

    <div style="width:40px;height:40px;background:#1E1E2E;border-radius:10px;display:flex;align-items:center;justify-content:center;">
      <span style="color:#7C3AED;font-size:20px;">⚡</span>
    </div>

    <div>
      <h2>AI Tool Detected</h2>
      <div class="sub">SentinelAI Monitoring System</div>
    </div>

  </div>

  {"<div class='alert-bar'>⚠️ This tool is on the <strong>blocked list</strong> — requires immediate review.</div>" if event.get('tool') in cfg.get('blocked_tools', []) else ""}

  <span class="badge {'coding' if 'Coding' in event.get('category','') else 'chat'}">
    {event.get('category','AI Tool')}
  </span>

  <h2 style="margin-top:10px">
    {event.get('tool','Unknown Tool')}
  </h2>

  <p class="sub">
    was accessed on <strong>{event.get('machine','')}</strong>
  </p>

  <table>

    <tr>
      <td>Detection Time</td>
      <td>{ts}</td>
    </tr>

    <tr>
      <td>Machine</td>
      <td>{event.get('machine','')}</td>
    </tr>

    <tr>
      <td>Employee</td>
      <td>{event.get('employee','') or event.get('os_user','')}</td>
    </tr>

    <tr>
      <td>Department</td>
      <td>{event.get('department','') or '—'}</td>
    </tr>

    <tr>
      <td>OS User</td>
      <td>{event.get('os_user','')}</td>
    </tr>

    <tr>
      <td>Detected via</td>
      <td>
        {event.get('match_type','').replace('_',' ').title()}
        ({event.get('matched_pattern','')})
      </td>
    </tr>

    {url_line}

    <tr>
      <td>Platform</td>
      <td>{event.get('platform','')}</td>
    </tr>

  </table>

  <div class="footer">
    SentinelAI · AI Activity Monitor · Automated Alert
  </div>

</div>

</body>
</html>
"""

        msg = MIMEMultipart("alternative")

        msg["Subject"] = subject
        msg["From"] = f"{cfg.get('email_from_name','SentinelAI')} <{cfg['smtp_user']}>"
        msg["To"] = ", ".join(cfg["alert_recipients"])

        text_body = f"AI tool detected: {event.get('tool','Unknown')} on {event.get('machine','Unknown')}\n\n"
        text_body += f"Time: {ts}\n"
        text_body += f"Machine: {event.get('machine','')}\n"
        text_body += f"Category: {event.get('category','')}\n"
        text_body += f"Employee: {event.get('employee','') or event.get('os_user','')}\n"
        text_body += f"URL: {event.get('url','')}\n"
        text_body += f"Detected via: {event.get('match_type','')} ({event.get('matched_pattern','')})\n"

        msg.attach(MIMEText(text_body, "plain"))
        msg.attach(MIMEText(html, "html"))

        print(f"[MAIL] Sending alert for {event['tool']} to {cfg['alert_recipients']}")
        if cfg.get("smtp_port") == 465:
            with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"]) as s:
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.sendmail(cfg["smtp_user"], cfg["alert_recipients"], msg.as_string())
        else:
            with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"]) as s:
                s.ehlo()
                s.starttls()
                s.ehlo()
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.sendmail(cfg["smtp_user"], cfg["alert_recipients"], msg.as_string())

        print(f"[MAIL] Alert sent for {event['tool']} on {event['machine']} at {ts}")
        return True

    except Exception as e:
        print(f"[MAIL ERROR] {e}")
        return False


def send_slack_alert(event: dict, cfg: dict):
    if not HAS_REQUESTS_IMPORT or not cfg.get("slack_webhook_url"):
        return
    try:
        ts = _format_event_timestamp(event.get("timestamp",""))
        payload = {
            "text": f"*[SentinelAI]* `{event['tool']}` detected on `{event['machine']}`",
            "blocks": [
                {"type": "header", "text": {"type": "plain_text", "text": f"⚡ AI Tool Detected: {event['tool']}"}},
                {"type": "section", "fields": [
                    {"type": "mrkdwn", "text": f"*Machine:*\n{event.get('machine','')}"},
                    {"type": "mrkdwn", "text": f"*Category:*\n{event.get('category','')}"},
                    {"type": "mrkdwn", "text": f"*Time:*\n{ts}"},
                    {"type": "mrkdwn", "text": f"*Employee:*\n{event.get('employee','') or event.get('os_user','')}"},
                    {"type": "mrkdwn", "text": f"*Detected via:*\n{event.get('match_type','')} ({event.get('matched_pattern','')}"},
                    {"type": "mrkdwn", "text": f"*Department:*\n{event.get('department','') or '—'}"},
                ]},
            ]
        }
        if event.get("url"):
            payload["blocks"].append({"type": "section", "text": {"type": "mrkdwn", "text": f"*URL:* {event['url'][:120]}"}})
        import requests as req
        req.post(cfg["slack_webhook_url"], json=payload, timeout=5)
        print(f"[SLACK] Alert sent for {event['tool']}")
    except Exception as e:
        print(f"[SLACK ERROR] {e}")


def send_teams_alert(event: dict, cfg: dict):
    if not cfg.get("teams_webhook_url"):
        return
    try:
        import requests as req
        ts = _format_event_timestamp(event.get("timestamp",""))
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "7C3AED",
            "summary": f"AI Tool Detected: {event['tool']}",
            "sections": [{
                "activityTitle": f"⚡ AI Tool Detected: {event['tool']}",
                "activitySubtitle": f"on {event.get('machine','')} at {ts}",
                "facts": [
                    {"name": "Category", "value": event.get("category","")},
                    {"name": "Machine", "value": event.get("machine","")},
                    {"name": "Employee", "value": event.get("employee","") or event.get("os_user","")},
                    {"name": "Department", "value": event.get("department","") or "—"},
                    {"name": "Detected via", "value": f"{event.get('match_type','')} ({event.get('matched_pattern','')})"},
                ],
            }]
        }
        if event.get("url"):
            payload["sections"][0]["facts"].append({"name": "URL", "value": event["url"][:120]})
        req.post(cfg["teams_webhook_url"], json=payload, timeout=5)
        print(f"[TEAMS] Alert sent for {event['tool']}")
    except Exception as e:
        print(f"[TEAMS ERROR] {e}")


def send_generic_webhook(event: dict, cfg: dict):
    if not cfg.get("generic_webhook_url"):
        return
    try:
        import requests as req
        req.post(cfg["generic_webhook_url"], json=event, timeout=5)
    except Exception as e:
        print(f"[WEBHOOK ERROR] {e}")


try:
    import requests as _r
    HAS_REQUESTS_IMPORT = True
except ImportError:
    HAS_REQUESTS_IMPORT = False


def dispatch_notifications(event: dict, cfg: dict):
    if not should_alert(event, cfg):
        return
    t = threading.Thread(target=_dispatch_worker, args=(event, cfg), daemon=True)
    t.start()


def _dispatch_worker(event: dict, cfg: dict):
    if cfg.get("email_enabled"):
        send_email_alert(event, cfg)
    if cfg.get("slack_enabled"):
        send_slack_alert(event, cfg)
    if cfg.get("teams_enabled"):
        send_teams_alert(event, cfg)
    if cfg.get("generic_webhook_enabled"):
        send_generic_webhook(event, cfg)


# ─── Routes ────────────────────────────────────────────────────────────────────

@app.route("/api/events", methods=["POST"])
def receive_event():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "No data"}), 400
    insert_event(data)
    cfg = load_server_config()
    dispatch_notifications(data, cfg)
    return jsonify({"ok": True}), 200


@app.route("/api/events/batch", methods=["POST"])
def receive_batch():
    data = request.get_json(silent=True)
    events = data.get("events", []) if data else []
    cfg = load_server_config()
    for e in events:
        insert_event(e)
        dispatch_notifications(e, cfg)
    return jsonify({"ok": True, "inserted": len(events)}), 200


@app.route("/api/events", methods=["GET"])
def get_events():
    filters = {
        "machine": request.args.get("machine"),
        "tool": request.args.get("tool"),
        "category": request.args.get("category"),
        "since": request.args.get("since"),
        "until": request.args.get("until"),
        "session": request.args.get("session"),
    }
    limit = int(request.args.get("limit", 200))
    events = query_events({k: v for k, v in filters.items() if v}, limit)
    return jsonify(events)


@app.route("/api/stats", methods=["GET"])
def get_stats_route():
    return jsonify(get_stats())


@app.route("/api/config", methods=["GET"])
def get_config_route():
    cfg = load_server_config()
    # Mask sensitive fields
    safe = {k: ("***" if "password" in k or "key" in k else v) for k, v in cfg.items()}
    return jsonify(safe)


@app.route("/api/config", methods=["POST"])
def update_config():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "No data"}), 400
    cfg = load_server_config()
    cfg.update(data)
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    return jsonify({"ok": True})


@app.route("/api/test-email", methods=["POST"])
def test_email():
    cfg = load_server_config()
    fake_event = {
        "id": "test001",
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
        "tool": "ChatGPT",
        "category": "Chat AI",
        "source": "test",
        "url": "https://chat.openai.com",
        "match_type": "domain",
        "matched_pattern": "chat.openai.com",
        "machine": "TEST-MACHINE",
        "employee": "Test User",
        "department": "IT",
        "os_user": "testuser",
        "platform": "Windows",
    }
    success = send_email_alert(fake_event, cfg)
    if success:
        return jsonify({"ok": True, "message": "Test email sent"})
    return jsonify({"ok": False, "error": "Email sending failed. Check server logs for details."}), 500


@app.route("/api/machines", methods=["GET"])
def get_machines():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT machine, MAX(timestamp) as last_seen, COUNT(*) as total_events,
               GROUP_CONCAT(DISTINCT tool) as tools_used
        FROM events GROUP BY machine ORDER BY last_seen DESC
    """)
    machines = [{"machine": r[0], "last_seen": r[1], "total_events": r[2],
                 "tools_used": r[3].split(",") if r[3] else []} for r in c.fetchall()]
    conn.close()
    return jsonify(machines)


# ─── Dashboard (serve React build) ────────────────────────────────────────────

@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_dashboard(path):
    if not DASHBOARD_DIR.exists():
        return (
            "Dashboard build not found. Run `cd dashboard && npm install && npm run build` "
            "then restart the server.", 500
        )
    if path and (DASHBOARD_DIR / path).exists():
        return send_from_directory(str(DASHBOARD_DIR), path)
    return send_from_directory(str(DASHBOARD_DIR), "index.html")


# ─── Startup ───────────────────────────────────────────────────────────────────

def init_session_state():
    global CURRENT_SESSION_START
    CURRENT_SESSION_START = datetime.datetime.utcnow().isoformat() + "Z"
    with open(SESSION_STATE_PATH, "w") as f:
        json.dump({"session_start": CURRENT_SESSION_START}, f, indent=2)


if __name__ == "__main__":
    init_db()
    init_session_state()
    cfg = load_server_config()
    print("=" * 56)
    print("  ⚡ SentinelAI Server Starting")
    print(f"  Dashboard: http://localhost:{cfg['port']}")
    print(f"  API: http://localhost:{cfg['port']}/api/events")
    print(f"  Email alerts: {'✓' if cfg['email_enabled'] else '✗ (disabled)'}")
    print(f"  Slack: {'✓' if cfg['slack_enabled'] else '✗ (disabled)'}")
    print("=" * 56)
    app.run(host=cfg["host"], port=cfg["port"], debug=False)
